from flask import Flask, render_template, url_for, request, redirect, jsonify
from datetime import datetime
import pandas as pd
import numpy as np
import requests
import json



app = Flask(__name__)

df=pd.read_csv("data/final_data.csv")
df['Ingredients'].fillna('')
df['Description'] = df['Ingredients'].str.lower() + df['Cuisine'].str.lower()+df['DishName'].str.lower()
df.dropna(subset=['DishName'], inplace=True)
df.dropna(subset=['Description'], inplace=True)
df['DishName'].drop_duplicates(inplace=True)



@app.route('/') #, methods=['POST','GET'])
def index():
        return render_template('index.html')

@app.route('/result/',methods = ['POST', 'GET'])
def result():
    if request.method == 'POST':

        ing = request.form['ing']

        dishes=recommend(ing)
        return render_template('result.html',tasks=dishes)
    else:
        return render_template('index.html')


@app.route('/dishrecipe/<dish>')
def dishrecipe(dish):

    url = "https://spoonacular-recipe-food-nutrition-v1.p.rapidapi.com/recipes/search"
    querystring = {"query":dish}
    headers = {
    'x-rapidapi-host': "spoonacular-recipe-food-nutrition-v1.p.rapidapi.com",
    'x-rapidapi-key': "<API-KEY>"
    }
#    print(querystring)
    response = requests.request("GET", url, headers=headers, params=querystring)
    dishes=json.loads(response.text)

    return render_template('spoonacular.html',tasks=dishes)

@app.route('/spoonacularrecipe/<id>')
def spoonacularrecipe(id):
    url = "https://spoonacular-recipe-food-nutrition-v1.p.rapidapi.com/recipes/"+id+"/information"
    headers = {
    'x-rapidapi-host': "spoonacular-recipe-food-nutrition-v1.p.rapidapi.com",
    'x-rapidapi-key': "<API-KEY>"
    }
    response = requests.request("GET", url, headers=headers)
    
    recipe=json.loads(response.text)

    return render_template('spoonacularrecipe.html',tasks=recipe)

def recommend(DishName):
    idx = df[df.Description.str.contains(DishName.lower())]
    return idx

if __name__ == "__main__":
    app.run(debug=True)

